'use client'

import { useState, useEffect } from 'react'
import ColorSwatch from './color-swatch'
import { generatePalette, getColorName, simulateColorBlindness } from '@/lib/color-utils'

export interface ColorPaletteGeneratorProps {
  initialColors?: string[]
  onChange?: (colors: string[]) => void
  colorBlindnessType: string | null
}

export default function ColorPaletteGenerator({ 
  initialColors = [
    '#274060',
    '#335C81',
    '#65AFFF',
    '#1B2845',
    '#5899E2'
  ],
  onChange,
  colorBlindnessType
}: ColorPaletteGeneratorProps) {
  const [colors, setColors] = useState(initialColors)
  const [lockedColors, setLockedColors] = useState(Array(5).fill(false))

  const updateColors = (newColors: string[]) => {
    setColors(newColors)
    onChange?.(newColors)
  }

  const generateNewPalette = () => {
    const newColors = colors.map((color, index) => 
      lockedColors[index] ? color : generatePalette(1)[0]
    )
    updateColors(newColors)
  }

  const toggleLock = (index: number) => {
    setLockedColors(lockedColors.map((locked, i) => 
      i === index ? !locked : locked
    ))
  }

  const updateColor = (index: number, newColor: string) => {
    const newColors = colors.map((color, i) => 
      i === index ? newColor : color
    )
    updateColors(newColors)
  }

  const getDisplayColors = () => {
    if (!colorBlindnessType) return colors
    return colors.map(color => simulateColorBlindness(color, colorBlindnessType))
  }

  useEffect(() => {
    const handleKeyPress = (event: KeyboardEvent) => {
      if (event.code === 'Space') {
        event.preventDefault()
        generateNewPalette()
      }
    }

    window.addEventListener('keydown', handleKeyPress)
    return () => {
      window.removeEventListener('keydown', handleKeyPress)
    }
  }, [colors, lockedColors])

  const displayColors = getDisplayColors()

  return (
    <div className="flex-1 flex">
      {displayColors.map((color, index) => (
        <ColorSwatch
          key={index}
          color={color}
          originalColor={colors[index]}
          name={getColorName(colors[index].replace('#', ''))}
          isLocked={lockedColors[index]}
          onToggleLock={() => toggleLock(index)}
          onColorChange={(newColor) => updateColor(index, newColor)}
        />
      ))}
    </div>
  )
}

