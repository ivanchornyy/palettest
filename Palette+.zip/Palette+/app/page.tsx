'use client'

import { useState } from 'react'
import { SiteHeader } from './components/site-header'
import ColorPaletteGenerator from './components/color-palette-generator'
import { Toaster } from '@/components/ui/toaster'

export default function Home() {
  const [colors, setColors] = useState([
    '#274060',
    '#335C81',
    '#65AFFF',
    '#1B2845',
    '#5899E2'
  ])
  const [colorBlindnessType, setColorBlindnessType] = useState<string | null>(null)

  return (
    <div className="min-h-screen flex flex-col">
      <SiteHeader 
        colors={colors}
        onColorsChange={setColors}
        onColorBlindnessChange={setColorBlindnessType}
        colorBlindnessType={colorBlindnessType}
      />
      <ColorPaletteGenerator 
        initialColors={colors}
        onChange={setColors}
        colorBlindnessType={colorBlindnessType}
      />
      <Toaster />
    </div>
  )
}

