'use client'

import { useState, useRef } from 'react'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Upload, Link2, Camera, Image } from 'lucide-react'
import { extractColorsFromImage } from '@/lib/color-utils'

interface ImageUploadModalProps {
  isOpen: boolean
  onClose: () => void
  onUpload: (colors: string[]) => void
}

export function ImageUploadModal({ isOpen, onClose, onUpload }: ImageUploadModalProps) {
  const [loading, setLoading] = useState(false)
  const [imageUrl, setImageUrl] = useState('')
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleFileUpload = async (file: File) => {
    setLoading(true)
    try {
      const url = URL.createObjectURL(file)
      const colors = await extractColorsFromImage(url)
      onUpload(colors)
      onClose()
    } catch (error) {
      console.error('Error processing image:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleUrlSubmit = async () => {
    if (!imageUrl) return
    setLoading(true)
    try {
      const colors = await extractColorsFromImage(imageUrl)
      onUpload(colors)
      onClose()
    } catch (error) {
      console.error('Error processing image URL:', error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Select image</DialogTitle>
        </DialogHeader>
        <Tabs defaultValue="upload">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="upload">Upload</TabsTrigger>
            <TabsTrigger value="url">URL</TabsTrigger>
            <TabsTrigger value="camera">Camera</TabsTrigger>
            <TabsTrigger value="stock">Stock</TabsTrigger>
          </TabsList>
          <TabsContent value="upload" className="py-4">
            <input
              type="file"
              ref={fileInputRef}
              className="hidden"
              accept="image/*"
              onChange={(e) => {
                const file = e.target.files?.[0]
                if (file) handleFileUpload(file)
              }}
            />
            <div 
              className="border-2 border-dashed rounded-lg p-8 text-center cursor-pointer"
              onClick={() => fileInputRef.current?.click()}
            >
              <Upload className="mx-auto h-12 w-12 text-gray-400" />
              <p className="mt-2 text-sm text-gray-600">Browse or drop image</p>
            </div>
          </TabsContent>
          <TabsContent value="url" className="py-4">
            <div className="space-y-4">
              <Input
                type="url"
                placeholder="Paste image URL"
                value={imageUrl}
                onChange={(e) => setImageUrl(e.target.value)}
              />
              <Button 
                className="w-full" 
                onClick={handleUrlSubmit}
                disabled={!imageUrl || loading}
              >
                Extract Colors
              </Button>
            </div>
          </TabsContent>
          <TabsContent value="camera" className="py-4">
            <div className="text-center py-8">
              <Camera className="mx-auto h-12 w-12 text-gray-400" />
              <p className="mt-2 text-sm text-gray-600">Camera access coming soon</p>
            </div>
          </TabsContent>
          <TabsContent value="stock" className="py-4">
            <div className="text-center py-8">
              <Image className="mx-auto h-12 w-12 text-gray-400" />
              <p className="mt-2 text-sm text-gray-600">Stock images coming soon</p>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  )
}

