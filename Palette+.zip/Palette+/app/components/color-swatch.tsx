'use client'

import { useState } from 'react'
import { HexColorPicker } from 'react-colorful'
import { Lock, Unlock } from 'lucide-react'
import { Shades } from './shades'

interface ColorSwatchProps {
  color: string
  originalColor: string
  name: string
  isLocked: boolean
  onToggleLock: () => void
  onColorChange: (newColor: string) => void
}

export default function ColorSwatch({ 
  color, 
  originalColor,
  name, 
  isLocked, 
  onToggleLock, 
  onColorChange 
}: ColorSwatchProps) {
  const [showPicker, setShowPicker] = useState(false)
  const [showShades, setShowShades] = useState(false)

  return (
    <div 
      className="flex-1 relative group cursor-pointer"
      style={{ backgroundColor: color }}
      onClick={() => !showPicker && setShowShades(!showShades)}
    >
      <div 
        className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-200"
        style={{
          background: `linear-gradient(to bottom, transparent 0%, ${color}99 50%, ${color} 100%)`
        }}
      />

      {showShades && (
        <Shades 
          baseColor={originalColor} 
          onSelectShade={(newColor) => {
            onColorChange(newColor)
            setShowShades(false)
          }}
        />
      )}

      <div className="absolute inset-x-0 bottom-0 p-6 flex flex-col items-center text-white z-10">
        <button
          onClick={(e) => {
            e.stopPropagation()
            setShowPicker(!showPicker)
            setShowShades(false)
          }}
          className="text-3xl font-mono font-bold uppercase mb-2"
        >
          {originalColor.replace('#', '')}
        </button>
        <div className="flex items-center gap-4">
          <span className="text-sm opacity-80">{name}</span>
          <button 
            onClick={(e) => {
              e.stopPropagation()
              onToggleLock()
            }}
            className="opacity-50 hover:opacity-100 transition-opacity"
          >
            {isLocked ? <Lock size={18} /> : <Unlock size={18} />}
          </button>
        </div>
      </div>

      {showPicker && (
        <div 
          className="absolute bottom-32 left-1/2 -translate-x-1/2 z-20"
          onClick={(e) => e.stopPropagation()}
        >
          <HexColorPicker 
            color={originalColor} 
            onChange={(newColor) => {
              onColorChange(newColor)
              setShowShades(false)
            }} 
          />
        </div>
      )}

      {color !== originalColor && (
        <div className="absolute top-2 right-2 bg-white text-black text-xs px-2 py-1 rounded-full">
          Simulated
        </div>
      )}
    </div>
  )
}

